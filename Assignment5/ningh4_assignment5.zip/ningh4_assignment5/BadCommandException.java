class BadCommandException extends RuntimeException {
    BadCommandException(String message) {
        super(message);
    }
}
